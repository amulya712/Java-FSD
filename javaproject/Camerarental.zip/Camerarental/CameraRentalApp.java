package Camerarental;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class Camera {
     String brand;
     String model;
     double rentalAmount;
     int id;
     boolean available;
     String rentedBy;
  //constructor
    public Camera(int id, String model, String brand, double rentalAmount) {
        this.brand = brand;
        this.id = id;
        this.model = model;
        this.rentalAmount = rentalAmount;
    }
//getters&setters
    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentalAmount() {
        return rentalAmount;
    }

    public int getId() {
        return id;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
    public String getRentedBy() {
        return rentedBy;
    }

    public void setRentedBy(String rentedBy) {
        this.rentedBy = rentedBy;
    }
}

class Wallet {
     double balance;
//getters&setters
    public Wallet() {
        this.balance = 2000;
    }

    public double getBalance() {
        return balance;
    }

    public void addFunds(double amount) {
        balance += amount;

    }
}
//main class
public class CameraRentalApp {

     List<Camera> cameras;
     Wallet wallet;
     Scanner scanner;
     String loggedInUser;
//constructor
    public CameraRentalApp() {
        cameras = new ArrayList<>();
        wallet = new Wallet();
        scanner = new Scanner(System.in);
        loggedInUser = "";
// cameras added        
        Camera camera1 = new Camera(1, " XC ", "Canon", 100.0);
        camera1.setAvailable(true);
        Camera camera2 = new Camera(2, " Digital", "Canon", 250.0);
        camera2.setAvailable(true);
        Camera camera3 = new Camera(3, "DSLR", " Nikon", 1000.0);
        camera3.setAvailable(true);
        Camera camera4 = new Camera(4, " Sony1234 ", "Sony", 600.0);
        camera4.setAvailable(true);
        Camera camera5 = new Camera(5, " 1234", "LG", 500.0);
        camera5.setAvailable(true);
        cameras.add(camera1);
        cameras.add(camera2);
        cameras.add(camera3);
        cameras.add(camera4);
        cameras.add(camera5);
    }
//class to login and validate login information   
 class LoginResult {
        String username;
        String password;

       public LoginResult(String username, String password) {
           this.username = username;
           this.password = password;
       }
//getters&setters
       public String getUsername() {
           return username;
       }

       public String getPassword() {
           return password;
       }
   }

   //validation of login class
    LoginResult validateLogin() {
       Scanner scanner = new Scanner(System.in);
       String message = "Welcome to the Camera Rental App";
       int messageLength = message.length();
       
       System.out.print("+");
       for (int i = 0; i < messageLength + 2; i++) {
           System.out.print("-");
       }
       System.out.println("+");
       
       System.out.println("| " + message + " |");
       
       System.out.print("+");
       for (int i = 0; i < messageLength + 2; i++) {
           System.out.print("-");
       }
       System.out.println("+");
      System.out.println("Developed by Amulya \n");
       System.out.print("PLEASE LOGIN TO CONTINUE \n");
       System.out.print("Enter username: ");
       String username = scanner.nextLine();

       System.out.print("Enter password: ");
       String password = scanner.nextLine();

       if (password.length() >= 6 && password.matches(".*\\d.*") && password.matches(".*[^a-zA-Z0-9].*")) {
           System.out.println("Login successful!");
           return new LoginResult(username, password);
          
       } else {
           System.out.println("Invalid login credentials.");
       }
		return null ;
   }
//method to display main menu
    public void displayWelcomeScreen() {
      
        System.out.println("Please select an option:");
        System.out.println("1. List Camera");
        System.out.println("2. My Cameras");
        System.out.println("3. Rent a Camera");
        System.out.println("4. My Wallet");
        System.out.println("5. Add Cameras");
        System.out.println("6. Exit");
    }
    
   //method to display submenu
     void myCameraSubMenu() {
        int choice;
//do while loop to continue the flow of switch cases        
do {
        	 Scanner scanner = new Scanner(System.in);
             String message = "My Camera Sub-Menu";
             int messageLength = message.length();
             
             System.out.print("+");
             for (int i = 0; i < messageLength + 2; i++) {
                 System.out.print("-");
             }
             System.out.println("+");
             
             System.out.println("| " + message + " |");
             
             System.out.print("+");
             for (int i = 0; i < messageLength + 2; i++) {
                 System.out.print("-");
             }
             System.out.println("+");
            System.out.println("1. Add a Camera");
            System.out.println("2. Remove a Camera");
            System.out.println("3. View My Cameras");
            System.out.println("4. Go Back");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCamera();
                    break;
                case 2:
                    removeCamera();
                    break;
                case 3:
                    viewMyCameras(cameras);
                    break;
                case 4:
                    System.out.println("Returning to main menu.");
                    System.out.println(" ");
                    System.out.println("Please select an option:");
                    System.out.println("1. List Camera");
                    System.out.println("2. My Cameras");
                    System.out.println("3. Rent a Camera");
                    System.out.println("4. My Wallet");
                    System.out.println("5. Add Cameras");
                    System.out.println("6. Exit");
                    choice = 0;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 0);
    }
//run method to run the application
     public void run() {
    	    LoginResult loginResult = validateLogin(); 
    	    
    	    if (loginResult == null) {
    	        System.out.println("Invalid login credentials. Exiting the program.");
    	        return;
    	    }
    	    
    	    loggedInUser = loginResult.getUsername();
        displayWelcomeScreen();
        int choice;

        do {
            System.out.print("\nEnter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
            case 1:
                displayCameraList(cameras);
            	
                break;
            case 2:
                  
                myCameraSubMenu();
                    break;
                
            case 3:
                 
                rentCamera();
                   
                    break;
            case 4:
                 addFundsToWallet();
                    break;
           case 5:
                  viewWalletBalance();
                    
           case 6:
                    System.out.println("Thank you for using the Camera Rental App. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 6);

        scanner.close();
    }
//method to addcamera
    public void addCamera() {
        System.out.print("Enter the camera Id: ");
        int id = scanner.nextInt();
        System.out.print("Enter the camera brand: ");
        String brand = scanner.next();
        System.out.print("Enter the camera model: ");
        String model = scanner.next();
        System.out.print("Enter the per-day rental amount: ");
        double rentalAmount = scanner.nextDouble();

        Camera camera = new Camera(id, model, brand, rentalAmount);
        camera.setAvailable(true);
        cameras.add(camera);
        System.out.println("Camera added successfully.");
    }
//method to remove camera
    public void removeCamera() {
        System.out.print("Enter the ID of the camera you want to remove: ");
        int cameraId = scanner.nextInt();

        Iterator<Camera> iterator = cameras.iterator();
        while (iterator.hasNext()) {
            Camera camera = iterator.next();
            if (camera.getId() == cameraId) {
                iterator.remove();
                System.out.println("Camera removed successfully.");
                return;
            }
        }

        System.out.println("Camera not found.");
    }
//method to display all cameras in list
     void displayCameraList(List<Camera> cameraList) {
        System.out.println("Camera List:");
        System.out.println("-----------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-15s | %-20s | %-25s| %-8s%n", "ID", "Brand", "Model", "(₹)Rental Amount(Per Day)","Status");
        System.out.println("-----------------------------------------------------------------------------------------------------------------");

        for (Camera camera : cameraList) {
            System.out.printf("%-5s | %-15s | %-20s | %-25s| %-8s%n",
                    camera.getId(), camera.getBrand(), camera.getModel(), camera.getRentalAmount(),
                    camera.isAvailable() ? "Available" : "Rented");
        }

        System.out.println("-----------------------------------------------------------------------------------------------------------------");
    }
//method to rent a camera
    public void rentCamera() {
    	displayCameraList(cameras);
        System.out.print("Enter the ID of the camera you want to rent: ");
        int cameraId = scanner.nextInt();
        Camera rentedCamera = null;

        for (Camera camera : cameras) {
            if (camera.getId() == cameraId && camera.isAvailable()) {
                double rentalAmount = camera.getRentalAmount();
                if (wallet.getBalance() >= rentalAmount) {
                    wallet.addFunds(-rentalAmount); 
                    camera.setAvailable(false);
                    camera.setRentedBy(loggedInUser);
                    rentedCamera = camera;
                 
                    System.out.printf("Current wallet balance: ₹%.2f%n", wallet.getBalance());
                    break;
                } else {
                    System.out.println("Insufficient funds. Please add funds to your wallet.");
                    return;
                }
            }
        }

        if (rentedCamera != null) {
            System.out.println("Camera rented successfully: " + rentedCamera.getBrand() + " " + rentedCamera.getModel()+" "+rentedCamera.getRentalAmount());
        } else {
            System.out.println("Camera not available for rent.");
        }
    }
//method to view cameras rented in my camera sub menu
     void viewMyCameras(List<Camera> cameraList) {
        System.out.println("My Rented Cameras:");
        System.out.println("----------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-15s | %-20s | %-15s%n", "ID", "Brand", "Model", "₹ Rental Amount(Per day)");
        System.out.println("-----------------------------------------------------------------------------------");

        for (Camera camera : cameraList) {
            if (!camera.isAvailable() && camera.getRentedBy().equals(loggedInUser)) {
                System.out.printf("%-5s | %-15s | %-20s | %-15s%n",
                        camera.getId(),camera.getBrand(), camera.getModel(),camera.getRentalAmount());
            }
        }

        System.out.println("------------------------------------------------------------------------------------");
    }
  //method to add money to wallet in my wallet
    public void addFundsToWallet() {
    	  System.out.printf("Current wallet balance: ₹%.2f%n", wallet.getBalance());
        System.out.print("Do you want to add funds to your wallet? (Yes/No): ");
        String choice = scanner.next();

        if (choice.equalsIgnoreCase("Yes")) {
            System.out.print("Enter the amount to add to the wallet: ");
            double amount = scanner.nextDouble();
            scanner.nextLine(); 

            wallet.addFunds(amount);
            System.out.print("Funds added successfully" );
            System.out.printf("\n Updated wallet balance: ₹%.2f%n", wallet.getBalance());
        } else if (choice.equalsIgnoreCase("No")) {
            System.out.println("Returning to the main menu.");
        } else {
            System.out.println("Invalid choice. Returning to the main menu.");
        }
    }
//method to view balance in wallet in my wallet 
    public void viewWalletBalance() {
        System.out.printf("Current wallet balance: ₹%.2f%n", wallet.getBalance());
    }
     boolean isLoggedIn() {
        return !loggedInUser.isEmpty();
    }
    public static void main(String[] args) {
        CameraRentalApp app = new CameraRentalApp();
        app.run();
    }
}

